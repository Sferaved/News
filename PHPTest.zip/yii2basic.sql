-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Мар 28 2022 г., 18:36
-- Версия сервера: 10.5.11-MariaDB-log
-- Версия PHP: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `yii2basic`
--

-- --------------------------------------------------------

--
-- Структура таблицы `migration`
--

CREATE TABLE `migration` (
  `version` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m220328_122456_create_news_table', 1648475587);

-- --------------------------------------------------------

--
-- Структура таблицы `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `news`
--

INSERT INTO `news` (`id`, `time`, `content`) VALUES
(1, 1648479372, 'content 1'),
(2, 1648481181, 'sdazsgedr'),
(3, 1648479404, 'awFGrfsdgfdhafdghjnghjm'),
(4, 1648481377, 'fxhgfdhfgdxhdgf'),
(5, 1648481561, 'gfxhgfdxhh'),
(6, 1648481602, 'xfghxfghfxghfx'),
(7, 1648479392, 'fghgjhujgkhgj'),
(8, 1648480489, 'цуаккуыпу'),
(9, 1648480857, ' unstiffened\r\n pummeling\r\n unmolten\r\n caliburno\r\n churruck\r\n afterwrath\r\n clericalist\r\n auroras\r\n bioluminescence\r\n uncomposed\r\n'),
(10, 1648481167, ' ranal\r\n undupability\r\n intercoastal\r\n sblood\r\n propeller\r\n casemates\r\n quayside\r\n infralittoral\r\n uncrowded\r\n cuissard\r\n'),
(11, 1648481434, ' shoepack\r\n seesawed\r\n rancorproof\r\n fullterm\r\n japanesque\r\n cohosted\r\n ancestorial\r\n cinnolin\r\n inflexive\r\n straitness\r\n'),
(12, 1648481583, ' galvanoplastic\r\n resonate\r\n taprobane\r\n concatenations\r\n unaffectioned\r\n huckle\r\n arose\r\n selenian\r\n toils\r\n bolting\r\n');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`version`);

--
-- Индексы таблицы `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
